=== APLICATIVO DOMINÓ MEXICANO (APK DE TESTES) ===

Versão: 1.0.0 (Offline CV)
Pacote: com.example.dominomexicano

COMO INSTALAR NO ANDROID:
1. Baixe este arquivo no seu celular Android.
2. Se o navegador avisar sobre arquivo desconhecido, selecione "Baixar mesmo assim".
3. Abra o arquivo .apk ou acesse a pasta Downloads.
4. Se solicitado, ative a opção "Permitir desta fonte" nas configurações do Android.
5. Toque em "Instalar" e divirta-se!

RECURSOS OFFLINE:
- Visão computacional 100% offline (Double-Double-Dominoes)
- Detecção de peças e contagem de pips sem internet
- Edição de peças individual e manual
- Placar para 2 a 10 jogadores e ranking em tempo real