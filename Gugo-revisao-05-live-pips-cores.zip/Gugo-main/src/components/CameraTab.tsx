import React, { useState, useRef, useEffect } from 'react';
import { Player, DetectedPiece, VisionResult, DominoTile } from '../types';
import { DominoPiece } from './DominoPiece';
import {
  detectDominoesOffline,
  drawDominoCVOverlay,
  CVOptions,
  OfflineCVResult,
} from '../utils/dominoDetectorCV';
import {
  Camera,
  Upload,
  RefreshCw,
  Sparkles,
  Check,
  AlertCircle,
  Plus,
  Trash2,
  Edit2,
  Calculator,
  Smartphone,
  Eye,
  SlidersHorizontal,
  Cpu,
  Bot,
  Zap,
} from 'lucide-react';

interface CameraTabProps {
  players: Player[];
  currentRound: number;
  onAssignScore: (playerId: string, score: number, pieces?: DominoTile[]) => void;
  onOpenApkModal?: () => void;
}

export const CameraTab: React.FC<CameraTabProps> = ({
  players,
  currentRound,
  onAssignScore,
  onOpenApkModal,
}) => {
  const [streamActive, setStreamActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [overlayImage, setOverlayImage] = useState<string | null>(null);
  const [showOverlay, setShowOverlay] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [visionResult, setVisionResult] = useState<VisionResult | null>(null);
  const [liveCVResult, setLiveCVResult] = useState<OfflineCVResult | null>(null);
  const [selectedPlayerId, setSelectedPlayerId] = useState<string>(players[0]?.id || '');
  const [assignSuccess, setAssignSuccess] = useState(false);

  // Engine selection: 'auto' (Try Gemini -> fallback Offline), 'gemini' (Online AI), 'offline' (Double-Double-Dominoes)
  const [engineMode, setEngineMode] = useState<'auto' | 'gemini' | 'offline'>('auto');

  // Computer Vision Controls & Tuning
  const [showCvSettings, setShowCvSettings] = useState(false);
  const [thresholdMode, setThresholdMode] = useState<'otsu' | 'manual'>('otsu');
  const [manualThreshold, setManualThreshold] = useState<number>(128);
  const [invertColors, setInvertColors] = useState<boolean>(false);
  const [lastRawImageData, setLastRawImageData] = useState<{
    width: number;
    height: number;
    data: Uint8ClampedArray;
  } | null>(null);

  // Individual Piece Editing State
  const [editingPieceId, setEditingPieceId] = useState<string | null>(null);
  const [editSideA, setEditSideA] = useState(6);
  const [editSideB, setEditSideB] = useState(6);

  // Manual Add Piece state
  const [showManualAdd, setShowManualAdd] = useState(false);
  const [manualA, setManualA] = useState(12);
  const [manualB, setManualB] = useState(9);

  // Direct Manual Score mode state
  const [showDirectScoreInput, setShowDirectScoreInput] = useState(false);
  const [directScoreValue, setDirectScoreValue] = useState<string>('');

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const liveOverlayRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      setCameraError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setStreamActive(true);
    } catch (err: any) {
      console.warn('Camera access issue:', err);
      setCameraError(
        'Não foi possível acessar a câmera do dispositivo. Você pode fazer upload de foto, adicionar peças manualmente ou usar as amostras predefinidas.'
      );
      setStreamActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setStreamActive(false);
  };

  // Live pip preview: sample the camera periodically before the shutter is pressed.
  useEffect(() => {
    if (!streamActive) {
      setLiveCVResult(null);
      const overlay = liveOverlayRef.current;
      const overlayCtx = overlay?.getContext('2d');
      if (overlayCtx && overlay) overlayCtx.clearRect(0, 0, overlay.width, overlay.height);
      return;
    }

    const sampleCanvas = document.createElement('canvas');
    const sampleCtx = sampleCanvas.getContext('2d', { willReadFrequently: true });
    if (!sampleCtx) return;

    const timer = window.setInterval(() => {
      const video = videoRef.current;
      const overlay = liveOverlayRef.current;
      if (!video || !overlay || video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA || !video.videoWidth) return;

      const scale = Math.min(1, 640 / video.videoWidth);
      const width = Math.max(1, Math.round(video.videoWidth * scale));
      const height = Math.max(1, Math.round(video.videoHeight * scale));
      sampleCanvas.width = width;
      sampleCanvas.height = height;
      sampleCtx.drawImage(video, 0, 0, width, height);
      const frame = sampleCtx.getImageData(0, 0, width, height);
      const result = detectDominoesOffline(frame.data, width, height, {
        thresholdMode: 'otsu',
        invertColors: false,
      });
      setLiveCVResult(result);

      // Paint detected pip centres over the live video at its native resolution.
      overlay.width = video.videoWidth;
      overlay.height = video.videoHeight;
      const overlayCtx = overlay.getContext('2d');
      if (overlayCtx) {
        overlayCtx.clearRect(0, 0, overlay.width, overlay.height);
        overlayCtx.save();
        overlayCtx.scale(overlay.width / width, overlay.height / height);
        drawDominoCVOverlay(overlayCtx, result, width, height);
        overlayCtx.restore();
      }
    }, 450);

    return () => window.clearInterval(timer);
  }, [streamActive]);

  const handleCaptureSnapshot = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.90);
    setCapturedImage(dataUrl);
    setLiveCVResult(null);
    stopCamera();

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setLastRawImageData({ width: canvas.width, height: canvas.height, data: imageData.data });

    processImage(dataUrl, imageData.data, canvas.width, canvas.height);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const input = e.currentTarget;
    const file = input.files?.[0];
    if (!file) return;
    // Reset immediately so the same photo can be selected again after tuning.
    input.value = '';

    if (!file.type.startsWith('image/')) {
      setCameraError('Selecione um ficheiro de imagem válido.');
      return;
    }

    setCameraError(null);
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setCapturedImage(dataUrl);
      stopCamera();

      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = Math.min(1280, img.width);
        canvas.height = Math.round((canvas.width / img.width) * img.height);
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        setLastRawImageData({ width: canvas.width, height: canvas.height, data: imageData.data });
        processImage(dataUrl, imageData.data, canvas.width, canvas.height);
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  /**
   * Dispatches image recognition based on user selection:
   * - 'auto': Tries Gemini AI Vision first. If offline/unavailable, runs local CV.
   * - 'gemini': Online Gemini AI Vision with individual piece cataloging.
   * - 'offline': 100% offline Double-Double-Dominoes multi-piece segmentation.
   */
  const processImage = async (
    dataUrl: string,
    pixelData: Uint8ClampedArray,
    width: number,
    height: number
  ) => {
    setIsAnalyzing(true);
    setVisionResult(null);
    setAssignSuccess(false);

    if (engineMode === 'offline') {
      runOfflineCV(pixelData, width, height, dataUrl);
      return;
    }

    try {
      // Call server-side API with Gemini AI vision
      const res = await fetch('/api/analyze-dominoes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: dataUrl,
          mode: engineMode,
        }),
      });

      if (!res.ok) {
        throw new Error(`Servidor retornou status ${res.status}`);
      }

      const data = await res.json();

      if (data.success && Array.isArray(data.pieces) && data.pieces.length > 0) {
        // Draw overlay for Gemini-detected pieces
        drawGeminiOverlay(dataUrl, data.pieces, width, height);

        setVisionResult({
          pieces: data.pieces,
          totalPoints: data.totalPoints,
          source: data.source || 'gemini_vision',
          warning: data.warning,
          imageUrl: dataUrl,
          timingMs: data.timingMs,
        });
        setIsAnalyzing(false);
        return;
      }

      // When Gemini API has quota exhausted or is unavailable, run local offline CV on the actual photo
      runOfflineCV(pixelData, width, height, dataUrl, {
        warning: data.message || (data.quotaExceeded ? 'Cota da IA Gemini atingida. Ativado motor offline no aparelho.' : undefined),
      });
    } catch (_err: any) {
      // Fallback seamlessly to offline CV without user-facing error interruption
      runOfflineCV(pixelData, width, height, dataUrl, {
        warning: 'Processamento 100% offline ativo no dispositivo.',
      });
    }
  };

  /**
   * Generates overlay canvas for Gemini detected pieces with 2D bounding boxes.
   */
  const drawGeminiOverlay = (
    originalDataUrl: string,
    pieces: DetectedPiece[],
    width: number,
    height: number
  ) => {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const baseImg = new Image();
    baseImg.onload = () => {
      ctx.drawImage(baseImg, 0, 0, width, height);

      pieces.forEach((piece) => {
        let x = 0;
        let y = 0;
        let w = 0;
        let h = 0;

        if (piece.box2d && piece.box2d.length === 4) {
          const [ymin, xmin, ymax, xmax] = piece.box2d;
          x = (xmin / 1000) * width;
          y = (ymin / 1000) * height;
          w = ((xmax - xmin) / 1000) * width;
          h = ((ymax - ymin) / 1000) * height;
        }

        if (w > 0 && h > 0) {
          ctx.strokeStyle = '#10b981';
          ctx.lineWidth = 3;
          ctx.strokeRect(x, y, w, h);
          ctx.fillStyle = 'rgba(16, 185, 129, 0.10)';
          ctx.fillRect(x, y, w, h);

          const label = `${piece.label} (${piece.points} pts)`;
          ctx.font = 'bold 13px system-ui, sans-serif';
          const tw = ctx.measureText(label).width;
          const badgeX = Math.max(4, Math.min(width - tw - 16, x));
          const badgeY = Math.max(4, y - 24);

          ctx.fillStyle = '#0f172a';
          ctx.beginPath();
          ctx.roundRect(badgeX, badgeY, tw + 14, 22, 6);
          ctx.fill();
          ctx.strokeStyle = '#10b981';
          ctx.lineWidth = 1;
          ctx.stroke();

          ctx.fillStyle = '#ffffff';
          ctx.fillText(label, badgeX + 7, badgeY + 15);
        }
      });

      // Gemini Watermark
      const badgeText = `🤖 IA Gemini Vision • ${pieces.length} peças catalogadas`;
      ctx.font = '11px system-ui, sans-serif';
      const badgeW = ctx.measureText(badgeText).width + 16;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.beginPath();
      ctx.roundRect(10, 10, badgeW, 22, 6);
      ctx.fill();
      ctx.fillStyle = '#38bdf8';
      ctx.fillText(badgeText, 18, 25);

      setOverlayImage(canvas.toDataURL('image/jpeg', 0.90));
    };
    baseImg.src = originalDataUrl;
  };

  /**
   * Executes 100% offline computer vision based on Double-Double-Dominoes.
   * Clusters all pips across the frame into multiple discrete domino pieces.
   */
  const runOfflineCV = (
    pixelData: Uint8ClampedArray,
    width: number,
    height: number,
    originalDataUrl: string,
    optionsOverride?: Partial<CVOptions> & { warning?: string }
  ) => {
    setIsAnalyzing(true);
    setVisionResult(null);
    setAssignSuccess(false);

    try {
      const cvOptions: CVOptions = {
        thresholdMode,
        manualThreshold,
        invertColors,
        ...optionsOverride,
      };

      const cvResult = detectDominoesOffline(pixelData, width, height, cvOptions);

      // Generate CV visualization overlay canvas
      const overlayCanvas = document.createElement('canvas');
      overlayCanvas.width = width;
      overlayCanvas.height = height;
      const overlayCtx = overlayCanvas.getContext('2d');

      if (overlayCtx) {
        const baseImg = new Image();
        baseImg.onload = () => {
          overlayCtx.drawImage(baseImg, 0, 0, width, height);
          drawDominoCVOverlay(overlayCtx, cvResult, width, height);
          const overlayUrl = overlayCanvas.toDataURL('image/jpeg', 0.90);
          setOverlayImage(overlayUrl);
        };
        baseImg.src = originalDataUrl;
      }

      // Never invent dominoes when the detector finds no reliable pieces.
      // An empty result is safer than silently assigning a fabricated score.
      const finalPieces = cvResult.pieces;
      const noPiecesWarning =
        finalPieces.length === 0
          ? 'Nenhuma peça foi identificada com confiança. Tente melhorar a iluminação, enquadrar as peças ou adicionar os dominós manualmente.'
          : undefined;
      const totalPts = finalPieces.reduce((sum, p) => sum + p.points, 0);

      setVisionResult({
        pieces: finalPieces,
        totalPoints: totalPts,
        source: 'offline_cv',
        warning: [optionsOverride?.warning, cvResult.warning, noPiecesWarning]
          .filter(Boolean)
          .join(' ') || undefined,
        imageUrl: originalDataUrl,
        timingMs: cvResult.processingTimeMs,
        thresholdUsed: cvResult.thresholdUsed,
        pipsTotal: cvResult.pipsTotal,
      });
    } catch (err: any) {
      console.error('Offline CV Error:', err);
      setVisionResult({
        pieces: [],
        totalPoints: 0,
        source: 'offline_cv',
        warning: 'Não foi possível analisar esta imagem. Nenhuma pontuação foi inventada; tente outra foto ou adicione as peças manualmente.',
        imageUrl: originalDataUrl,
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleReprocessWithNewSettings = () => {
    if (lastRawImageData && capturedImage) {
      if (engineMode === 'offline') {
        runOfflineCV(
          lastRawImageData.data,
          lastRawImageData.width,
          lastRawImageData.height,
          capturedImage,
          {
            thresholdMode,
            manualThreshold,
            invertColors,
          }
        );
      } else {
        processImage(
          capturedImage,
          lastRawImageData.data,
          lastRawImageData.width,
          lastRawImageData.height
        );
      }
    }
  };

  /**
   * Generates realistic multi-domino synthetic test images.
   */
  const handleUseSample = (type: 'hand42' | 'hand52' | 'hand15') => {
    const canvas = document.createElement('canvas');
    canvas.width = 680;
    canvas.height = 420;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Dark green felt table
    ctx.fillStyle = '#152e22';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Subtle table felt texture/border
    ctx.strokeStyle = '#234e3b';
    ctx.lineWidth = 4;
    ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);

    if (type === 'hand42') {
      // 3 Dominoes: [12|9] = 21, [4|7] = 11, [5|5] = 10 -> Total 42 pts
      drawSyntheticDomino(ctx, 50, 70, 150, 270, 12, 9);
      drawSyntheticDomino(ctx, 260, 70, 150, 270, 4, 7);
      drawSyntheticDomino(ctx, 470, 70, 150, 270, 5, 5);
    } else if (type === 'hand52') {
      // 5 Dominoes: [12|8] = 20, [9|9] = 18, [7|3] = 10, [2|4] = 6, [0|0] = 0 -> Total 54 pts
      drawSyntheticDomino(ctx, 35, 75, 105, 195, 12, 8);
      drawSyntheticDomino(ctx, 160, 75, 105, 195, 9, 9);
      drawSyntheticDomino(ctx, 285, 75, 105, 195, 7, 3);
      drawSyntheticDomino(ctx, 410, 75, 105, 195, 2, 4);
      drawSyntheticDomino(ctx, 535, 75, 105, 195, 0, 0);
    } else {
      // 2 Dominoes: [2|3] = 5, [1|9] = 10 -> Total 15 pts
      drawSyntheticDomino(ctx, 140, 80, 160, 280, 2, 3);
      drawSyntheticDomino(ctx, 380, 80, 160, 280, 1, 9);
    }

    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
    setCapturedImage(dataUrl);
    stopCamera();

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setLastRawImageData({ width: canvas.width, height: canvas.height, data: imgData.data });
    processImage(dataUrl, imgData.data, canvas.width, canvas.height);
  };

  const drawSyntheticDomino = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    sideA: number,
    sideB: number
  ) => {
    // Ivory body with bevel
    ctx.fillStyle = '#fafaf9';
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, 14);
    ctx.fill();
    ctx.strokeStyle = '#d4d4d8';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Central metal pin / divider
    ctx.strokeStyle = '#52525b';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x + 8, y + h / 2);
    ctx.lineTo(x + w - 8, y + h / 2);
    ctx.stroke();

    // Metal rivet in center
    ctx.fillStyle = '#71717a';
    ctx.beginPath();
    ctx.arc(x + w / 2, y + h / 2, 4, 0, Math.PI * 2);
    ctx.fill();

    const drawPipsGroup = (count: number, isTop: boolean) => {
      if (count === 0) return;
      const centerY = isTop ? y + h / 4 : y + (3 * h) / 4;
      const centerX = x + w / 2;
      const r = Math.max(3.5, Math.min(6, w * 0.045));
      ctx.fillStyle = isTop ? '#0f172a' : '#1d4ed8';

      const dX = w * 0.23;
      const dY = h * 0.11;

      if (count === 1) {
        ctx.beginPath(); ctx.arc(centerX, centerY, r, 0, Math.PI * 2); ctx.fill();
      } else if (count === 2) {
        ctx.beginPath(); ctx.arc(centerX - dX, centerY - dY, r, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(centerX + dX, centerY + dY, r, 0, Math.PI * 2); ctx.fill();
      } else if (count === 3) {
        ctx.beginPath(); ctx.arc(centerX - dX, centerY - dY, r, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(centerX, centerY, r, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(centerX + dX, centerY + dY, r, 0, Math.PI * 2); ctx.fill();
      } else if (count === 4) {
        ctx.beginPath(); ctx.arc(centerX - dX, centerY - dY, r, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(centerX + dX, centerY - dY, r, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(centerX - dX, centerY + dY, r, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(centerX + dX, centerY + dY, r, 0, Math.PI * 2); ctx.fill();
      } else if (count === 5) {
        ctx.beginPath(); ctx.arc(centerX - dX, centerY - dY, r, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(centerX + dX, centerY - dY, r, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(centerX, centerY, r, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(centerX - dX, centerY + dY, r, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(centerX + dX, centerY + dY, r, 0, Math.PI * 2); ctx.fill();
      } else {
        const rows = count <= 6 ? 3 : 4;
        const cols = count <= 6 ? 2 : 3;
        let drawn = 0;
        for (let rIdx = 0; rIdx < rows; rIdx++) {
          for (let cIdx = 0; cIdx < cols; cIdx++) {
            if (drawn < count) {
              const px = centerX - dX + (cIdx * (2 * dX)) / Math.max(1, cols - 1);
              const py = centerY - dY + (rIdx * (2 * dY)) / Math.max(1, rows - 1);
              ctx.beginPath();
              ctx.arc(px, py, r, 0, Math.PI * 2);
              ctx.fill();
              drawn++;
            }
          }
        }
      }
    };

    drawPipsGroup(sideA, true);
    drawPipsGroup(sideB, false);
  };

  // Add piece manually to current count
  const handleAddManualPiece = () => {
    const a = Math.min(manualA, manualB);
    const b = Math.max(manualA, manualB);
    const newPiece: DetectedPiece = {
      id: `manual-add-${Date.now()}`,
      sideA: a,
      sideB: b,
      points: a + b,
      label: `[${a}|${b}]`,
      confidence: 1.0,
    };

    if (visionResult) {
      const updated = [...visionResult.pieces, newPiece];
      const total = updated.reduce((sum, p) => sum + p.points, 0);
      setVisionResult({
        ...visionResult,
        pieces: updated,
        totalPoints: total,
      });
    } else {
      setVisionResult({
        pieces: [newPiece],
        totalPoints: newPiece.points,
        source: 'manual',
      });
    }
    setShowManualAdd(false);
  };

  // Start individual piece editing
  const handleStartPieceEdit = (piece: DetectedPiece) => {
    setEditingPieceId(piece.id);
    setEditSideA(piece.sideA);
    setEditSideB(piece.sideB);
  };

  // Save individual piece editing
  const handleSavePieceEdit = (pieceId: string) => {
    if (!visionResult) return;
    const a = Math.min(editSideA, editSideB);
    const b = Math.max(editSideA, editSideB);

    const updated = visionResult.pieces.map((p) => {
      if (p.id === pieceId) {
        return {
          ...p,
          sideA: a,
          sideB: b,
          points: a + b,
          label: `[${a}|${b}]`,
        };
      }
      return p;
    });

    const total = updated.reduce((sum, p) => sum + p.points, 0);
    setVisionResult({
      ...visionResult,
      pieces: updated,
      totalPoints: total,
    });
    setEditingPieceId(null);
  };

  // Remove individual piece
  const handleRemovePiece = (id: string) => {
    if (!visionResult) return;
    const updated = visionResult.pieces.filter((p) => p.id !== id);
    const total = updated.reduce((sum, p) => sum + p.points, 0);
    setVisionResult({
      ...visionResult,
      pieces: updated,
      totalPoints: total,
    });
    if (editingPieceId === id) setEditingPieceId(null);
  };

  // Direct manual score submit
  const handleApplyDirectManualScore = () => {
    const scoreNum = Math.max(0, parseInt(directScoreValue, 10) || 0);
    if (!selectedPlayerId) return;
    onAssignScore(selectedPlayerId, scoreNum, []);
    setAssignSuccess(true);
    setTimeout(() => setAssignSuccess(false), 3000);
    setShowDirectScoreInput(false);
  };

  // Assign vision/piece score to player
  const handleConfirmAssign = () => {
    if (!visionResult || visionResult.pieces.length === 0 || !selectedPlayerId) return;
    const tiles: DominoTile[] = visionResult.pieces.map((p) => ({
      id: `${p.sideA}-${p.sideB}-${p.id}`,
      sideA: p.sideA,
      sideB: p.sideB,
    }));
    onAssignScore(selectedPlayerId, visionResult.totalPoints, tiles);
    setAssignSuccess(true);
    setTimeout(() => setAssignSuccess(false), 3000);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="rounded-2xl bg-linear-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white p-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-xl backdrop-blur-xs">
              <Camera className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold leading-tight">Contagem e Reconhecimento Multi-Peças</h2>
              <p className="text-xs text-emerald-100">
                Lê o conjunto completo e cataloga peça por peça
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {onOpenApkModal && (
              <button
                type="button"
                onClick={onOpenApkModal}
                className="hidden sm:flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-emerald-50 text-emerald-800 rounded-full font-bold text-[11px] shadow-xs transition-colors"
                title="Baixar APK ou Instalar no Android"
              >
                <Smartphone className="w-3 h-3" />
                <span>Baixar APK</span>
              </button>
            )}
          </div>
        </div>

        {/* Engine Selector Segmented Control */}
        <div className="mt-3.5 pt-3 border-t border-white/20">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
            <span className="text-[11px] font-semibold text-emerald-100 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-300" />
              Motor de Visão:
            </span>

            <div className="flex bg-black/20 p-1 rounded-xl backdrop-blur-xs">
              <button
                type="button"
                onClick={() => setEngineMode('auto')}
                className={`flex-1 sm:flex-none px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  engineMode === 'auto'
                    ? 'bg-white text-emerald-900 shadow-xs'
                    : 'text-emerald-100 hover:text-white'
                }`}
              >
                <Zap className="w-3 h-3" />
                <span>Automático</span>
              </button>

              <button
                type="button"
                onClick={() => setEngineMode('gemini')}
                className={`flex-1 sm:flex-none px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  engineMode === 'gemini'
                    ? 'bg-white text-emerald-900 shadow-xs'
                    : 'text-emerald-100 hover:text-white'
                }`}
              >
                <Bot className="w-3 h-3" />
                <span>IA Gemini</span>
              </button>

              <button
                type="button"
                onClick={() => setEngineMode('offline')}
                className={`flex-1 sm:flex-none px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  engineMode === 'offline'
                    ? 'bg-white text-emerald-900 shadow-xs'
                    : 'text-emerald-100 hover:text-white'
                }`}
              >
                <Cpu className="w-3 h-3" />
                <span>100% Offline</span>
              </button>
            </div>
          </div>
        </div>

        {/* Quick action buttons in header */}
        <div className="mt-3 pt-2.5 border-t border-white/15 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowDirectScoreInput(!showDirectScoreInput)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-bold transition-all"
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>Inserir Pontuação Direta</span>
            </button>

            <button
              type="button"
              onClick={() => setShowManualAdd(!showManualAdd)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-bold transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Adicionar Peça</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => setShowCvSettings(!showCvSettings)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              showCvSettings
                ? 'bg-white text-emerald-900 shadow-sm'
                : 'bg-white/20 hover:bg-white/30 text-white'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Ajustes CV</span>
          </button>
        </div>
      </div>

      {/* CV Offline Parameter Tuning Panel */}
      {showCvSettings && (
        <div className="p-4 bg-white dark:bg-zinc-900 rounded-2xl border border-emerald-500/40 shadow-sm space-y-3 animate-in fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <h3 className="text-xs font-black uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
                Ajustes de Segmentação Offline (Double-Double-Dominoes)
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setShowCvSettings(false)}
              className="text-xs text-zinc-400 hover:text-zinc-600"
            >
              Fechar
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="space-y-1">
              <label className="text-zinc-600 dark:text-zinc-400 font-semibold">
                Modo de Limiar:
              </label>
              <div className="flex rounded-lg bg-zinc-100 dark:bg-zinc-800 p-1">
                <button
                  type="button"
                  onClick={() => setThresholdMode('otsu')}
                  className={`flex-1 py-1 rounded text-center font-bold ${
                    thresholdMode === 'otsu'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-zinc-600 dark:text-zinc-400'
                  }`}
                >
                  Otsu Automático
                </button>
                <button
                  type="button"
                  onClick={() => setThresholdMode('manual')}
                  className={`flex-1 py-1 rounded text-center font-bold ${
                    thresholdMode === 'manual'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-zinc-600 dark:text-zinc-400'
                  }`}
                >
                  Manual
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <label className="text-zinc-600 dark:text-zinc-400 font-semibold">
                  Limiar: {manualThreshold}
                </label>
                <span className="text-[10px] text-zinc-400 font-mono">0-255</span>
              </div>
              <input
                type="range"
                min="30"
                max="225"
                disabled={thresholdMode === 'otsu'}
                value={manualThreshold}
                onChange={(e) => setManualThreshold(Number(e.target.value))}
                className="w-full accent-emerald-600"
              />
            </div>

            <div className="flex items-center justify-between sm:justify-center gap-2 pt-2 sm:pt-0">
              <label className="text-zinc-600 dark:text-zinc-400 font-semibold cursor-pointer flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={invertColors}
                  onChange={(e) => setInvertColors(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                />
                <span>Peças com fundo escuro (inverter)</span>
              </label>
            </div>
          </div>

          <div className="flex justify-end pt-2 border-t border-zinc-100 dark:border-zinc-800">
            <button
              type="button"
              onClick={handleReprocessWithNewSettings}
              disabled={!capturedImage}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg font-bold text-xs transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reprocessar Imagem</span>
            </button>
          </div>
        </div>
      )}

      {/* Direct Manual Score Drawer */}
      {showDirectScoreInput && (
        <div className="p-4 bg-white dark:bg-zinc-900 rounded-2xl border-2 border-emerald-500 shadow-md space-y-3 animate-in fade-in">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
              Lançamento Manual Direto (Sem Peças)
            </h3>
            <button
              type="button"
              onClick={() => setShowDirectScoreInput(false)}
              className="text-xs text-zinc-400 hover:text-zinc-600"
            >
              Fechar
            </button>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <div className="flex-1 flex items-center gap-2">
              <span className="text-xs text-zinc-500 font-bold whitespace-nowrap">Jogador:</span>
              <select
                aria-label="Jogador para pontuação manual"
                value={selectedPlayerId}
                onChange={(e) => setSelectedPlayerId(e.target.value)}
                className="flex-1 bg-zinc-100 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-xl px-3 py-2 text-xs font-bold"
              >
                {players.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.avatar} {p.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="number"
                min="0"
                placeholder="Pts"
                value={directScoreValue}
                onChange={(e) => setDirectScoreValue(e.target.value)}
                className="w-24 px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-xl text-center text-sm font-black"
              />
              <button
                type="button"
                onClick={handleApplyDirectManualScore}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all"
              >
                Gravar
              </button>
              <button
                type="button"
                onClick={() => {
                  setDirectScoreValue('0');
                  onAssignScore(selectedPlayerId, 0, []);
                  setAssignSuccess(true);
                  setTimeout(() => setAssignSuccess(false), 3000);
                  setShowDirectScoreInput(false);
                }}
                className="px-3 py-2 bg-amber-500 hover:bg-amber-600 text-zinc-950 rounded-xl text-xs font-black shadow-xs transition-all"
                title="Bateu com 0 pontos"
              >
                0 (Bateu)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manual Add Piece Panel */}
      {showManualAdd && (
        <div className="p-3.5 bg-white dark:bg-zinc-900 rounded-2xl border border-emerald-500/40 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100">
              Adicionar Peça de Dominó Manualmente:
            </span>
            <button
              type="button"
              onClick={() => setShowManualAdd(false)}
              className="text-xs text-zinc-400 hover:text-zinc-600"
            >
              Cancelar
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex-1 flex items-center gap-1.5">
              <label htmlFor="cam-manual-side-a" className="text-xs text-zinc-500">Lado A:</label>
              <select
                id="cam-manual-side-a"
                aria-label="Lado A do dominó"
                value={manualA}
                onChange={(e) => setManualA(Number(e.target.value))}
                className="flex-1 bg-zinc-50 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg p-1.5 text-xs font-bold"
              >
                {Array.from({ length: 13 }).map((_, i) => (
                  <option key={i} value={i}>
                    {i}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex-1 flex items-center gap-1.5">
              <label htmlFor="cam-manual-side-b" className="text-xs text-zinc-500">Lado B:</label>
              <select
                id="cam-manual-side-b"
                aria-label="Lado B do dominó"
                value={manualB}
                onChange={(e) => setManualB(Number(e.target.value))}
                className="flex-1 bg-zinc-50 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg p-1.5 text-xs font-bold"
              >
                {Array.from({ length: 13 }).map((_, i) => (
                  <option key={i} value={i}>
                    {i}
                  </option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={handleAddManualPiece}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all"
            >
              Inserir [{Math.min(manualA, manualB)}|{Math.max(manualA, manualB)}]
            </button>
          </div>
        </div>
      )}

      {/* Camera / Viewfinder Box */}
      <div className="relative rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-sm aspect-4/3 flex flex-col items-center justify-center">
        {/* Live Video Feed */}
        <video
          ref={videoRef}
          playsInline
          muted
          className={`absolute inset-0 w-full h-full object-cover ${
            streamActive ? 'block' : 'hidden'
          }`}
        />
        {streamActive && (
          <>
            <canvas
              ref={liveOverlayRef}
              aria-label="Marcação em direto dos pips detetados"
              className="absolute inset-0 w-full h-full object-cover pointer-events-none"
            />
            <div className="absolute top-3 left-3 right-3 z-10 flex flex-wrap items-center gap-2 pointer-events-none">
              <div className="rounded-xl bg-black/80 border border-emerald-400/60 px-3 py-2 text-white shadow-lg backdrop-blur-sm">
                <div className="text-[10px] uppercase tracking-wider font-bold text-emerald-300">Contagem em direto</div>
                <div className="text-lg font-black leading-tight">
                  {liveCVResult ? `${liveCVResult.pipsTotal} pips` : 'A analisar…'}
                </div>
              </div>
              <div className="rounded-xl bg-black/80 border border-white/20 px-3 py-2 text-white shadow-lg backdrop-blur-sm">
                <div className="text-[10px] uppercase tracking-wider font-bold text-cyan-300">Peças / pontos</div>
                <div className="text-sm font-extrabold leading-tight">
                  {liveCVResult ? `${liveCVResult.tilesCount} peças · ${liveCVResult.totalPoints} pts` : '—'}
                </div>
              </div>
            </div>
            {liveCVResult && liveCVResult.tilesCount > 0 && (
              <div className="absolute bottom-3 left-3 right-3 z-10 rounded-xl bg-black/80 border border-white/20 px-3 py-2 text-white text-xs font-semibold backdrop-blur-sm pointer-events-none">
                {liveCVResult.tiles.slice(0, 6).map((tile, index) => (
                  <span key={tile.id} className="inline-block mr-2 text-emerald-200">
                    {`[${tile.sideA}|${tile.sideB}]`}
                  </span>
                ))}
              </div>
            )}
          </>
        )}

        {/* Captured Image / CV Overlay View */}
        {capturedImage && !streamActive && (
          <img
            src={showOverlay && overlayImage ? overlayImage : capturedImage}
            alt="Foto do conjunto de dominós processada"
            className="absolute inset-0 w-full h-full object-contain bg-zinc-950"
          />
        )}

        {/* Toggle overlay badge when image is available */}
        {capturedImage && overlayImage && !streamActive && (
          <div className="absolute bottom-3 right-3 z-10">
            <button
              type="button"
              onClick={() => setShowOverlay(!showOverlay)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/75 hover:bg-black text-white text-xs font-bold backdrop-blur-xs border border-white/20 shadow-md transition-all"
            >
              <Eye className="w-3.5 h-3.5 text-emerald-400" />
              <span>{showOverlay ? 'Ver Foto Limpa' : 'Ver Caixas e Pips'}</span>
            </button>
          </div>
        )}

        {/* Idle View when no camera and no photo */}
        {!streamActive && !capturedImage && (
          <div className="text-center p-6 space-y-3 z-1">
            <div className="w-16 h-16 rounded-full bg-zinc-800/80 border border-zinc-700 flex items-center justify-center mx-auto text-zinc-400">
              <Camera className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Fotografar Conjunto de Peças</h3>
              <p className="text-xs text-zinc-400 max-w-xs mt-1">
                Reconhece múltiplas peças no tabuleiro e cataloga individualmente cada dominó com sua pontuação.
              </p>
            </div>
          </div>
        )}

        {/* Viewfinder Target Guidelines */}
        {(streamActive || capturedImage) && (
          <div className="absolute inset-4 pointer-events-none border-2 border-white/20 rounded-xl flex flex-col justify-between p-2">
            <div className="flex justify-between">
              <div className="w-4 h-4 border-t-2 border-l-2 border-emerald-400" />
              <div className="w-4 h-4 border-t-2 border-r-2 border-emerald-400" />
            </div>
            <div className="flex justify-between">
              <div className="w-4 h-4 border-b-2 border-l-2 border-emerald-400" />
              <div className="w-4 h-4 border-b-2 border-r-2 border-emerald-400" />
            </div>
          </div>
        )}

        {/* Analyzing Overlay Spinner */}
        {isAnalyzing && (
          <div className="absolute inset-0 bg-black/75 backdrop-blur-xs flex flex-col items-center justify-center z-20 space-y-3">
            <div className="w-12 h-12 rounded-full border-4 border-emerald-500 border-t-transparent animate-spin" />
            <div className="text-center">
              <p className="text-sm font-bold text-white">
                {engineMode === 'offline'
                  ? 'Processando Visão Offline Multi-Peças...'
                  : 'Catalogando Peças com IA Gemini...'}
              </p>
              <p className="text-xs text-emerald-300">
                Segmentando e catalogando dominós um a um
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Camera Error Notice if any */}
      {cameraError && (
        <div className="flex items-start gap-2 p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800/50 rounded-xl text-xs text-amber-800 dark:text-amber-300">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{cameraError}</span>
        </div>
      )}

      {/* Action Buttons Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {!streamActive ? (
          <button
            type="button"
            onClick={startCamera}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs shadow-xs transition-all"
          >
            <Camera className="w-4 h-4" />
            <span>Abrir Câmera</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={handleCaptureSnapshot}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs shadow-xs transition-all animate-pulse"
          >
            <Check className="w-4 h-4" />
            <span>Tirar Foto</span>
          </button>
        )}

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 font-semibold text-xs border border-zinc-200 dark:border-zinc-700 transition-all"
        >
          <Upload className="w-4 h-4" />
          <span>Escolher da Galeria</span>
        </button>

        <button
          type="button"
          onClick={() => handleUseSample('hand42')}
          className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:hover:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300 font-semibold text-xs border border-emerald-200 dark:border-emerald-800 transition-all"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>3 Peças (42 pts)</span>
        </button>

        <button
          type="button"
          onClick={() => handleUseSample('hand52')}
          className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-teal-50 hover:bg-teal-100 dark:bg-teal-950/50 dark:hover:bg-teal-900/50 text-teal-700 dark:text-teal-300 font-semibold text-xs border border-teal-200 dark:border-teal-800 transition-all"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>5 Peças (54 pts)</span>
        </button>

        <button
          type="button"
          onClick={() => handleUseSample('hand15')}
          className="col-span-2 sm:col-span-1 flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 font-semibold text-xs border border-zinc-200 dark:border-zinc-700 transition-all"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>2 Peças (15 pts)</span>
        </button>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/heic,image/heif"
          aria-label="Selecionar fotografia da galeria"
          className="hidden"
          onChange={handleFileUpload}
        />
      </div>

      {/* Detection Results & Scores Breakdown with Individual Editing */}
      {visionResult && (
        <div className="bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 p-4 shadow-sm space-y-4">
          {/* Header Summary */}
          <div className="flex items-center justify-between border-b border-zinc-100 dark:border-zinc-800 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                  {visionResult.source === 'gemini_vision' ? (
                    <>
                      <Bot className="w-3.5 h-3.5 text-sky-500" />
                      <span>Catálogo IA Gemini</span>
                    </>
                  ) : (
                    <>
                      <Cpu className="w-3.5 h-3.5 text-emerald-500" />
                      <span>Visão Offline Double-Double</span>
                    </>
                  )}
                  {visionResult.timingMs ? ` (${visionResult.timingMs}ms)` : ''}
                </span>
              </div>
              <h3 className="text-base font-extrabold text-zinc-900 dark:text-zinc-100">
                {visionResult.pieces.length} {visionResult.pieces.length === 1 ? 'Peça Catalogada' : 'Peças Catalogadas Individualmente'}
              </h3>
            </div>

            {/* Total Accumulated Score */}
            <div className="flex flex-col items-end">
              <span className="text-[11px] text-zinc-500 dark:text-zinc-400">
                {visionResult.pieces.length} {visionResult.pieces.length === 1 ? 'peça' : 'peças'} · Total da Mão
              </span>
              <div className="px-3.5 py-1 rounded-xl bg-linear-to-r from-red-500 to-rose-600 text-white font-black text-xl shadow-sm">
                {visionResult.totalPoints} pts
              </div>
            </div>
          </div>

          {visionResult.warning && (
            <div className="p-2.5 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl text-xs text-amber-800 dark:text-amber-300">
              {visionResult.warning}
            </div>
          )}

          {/* List of Detected Pieces with individual scores and INLINE EDITING */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-zinc-700 dark:text-zinc-300">
              <span>Peças Identificadas (Toque no lápis para alterar lados):</span>
              <button
                type="button"
                onClick={() => setShowManualAdd(true)}
                className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1 hover:underline"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Adicionar mais uma</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {visionResult.pieces.map((piece, index) => {
                const isEditing = editingPieceId === piece.id;

                return (
                  <div
                    key={piece.id}
                    className={`p-3 rounded-xl border transition-all ${
                      isEditing
                        ? 'bg-amber-50/60 dark:bg-amber-950/30 border-amber-500 shadow-xs'
                        : 'bg-zinc-50 dark:bg-zinc-800/60 border-zinc-200 dark:border-zinc-800 hover:border-zinc-300'
                    }`}
                  >
                    {isEditing ? (
                      /* Inline Editor for this piece */
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-amber-900 dark:text-amber-300">
                            Peça #{index + 1}: [{editSideA}|{editSideB}] ({editSideA + editSideB} pts):
                          </span>
                          <button
                            type="button"
                            onClick={() => handleSavePieceEdit(piece.id)}
                            className="flex items-center gap-1 px-2.5 py-1 bg-emerald-600 text-white rounded-lg text-xs font-bold shadow-xs hover:bg-emerald-700"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Gravar</span>
                          </button>
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="flex-1 flex items-center gap-1.5">
                            <span className="text-[11px] text-zinc-500 font-semibold">Lado A:</span>
                            <select
                              aria-label="Editar Lado A da peça"
                              value={editSideA}
                              onChange={(e) => setEditSideA(Number(e.target.value))}
                              className="flex-1 bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 rounded-lg p-1.5 text-xs font-bold"
                            >
                              {Array.from({ length: 13 }).map((_, i) => (
                                <option key={i} value={i}>
                                  {i}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div className="flex-1 flex items-center gap-1.5">
                            <span className="text-[11px] text-zinc-500 font-semibold">Lado B:</span>
                            <select
                              aria-label="Editar Lado B da peça"
                              value={editSideB}
                              onChange={(e) => setEditSideB(Number(e.target.value))}
                              className="flex-1 bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 rounded-lg p-1.5 text-xs font-bold"
                            >
                              {Array.from({ length: 13 }).map((_, i) => (
                                <option key={i} value={i}>
                                  {i}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </div>
                    ) : (
                      /* Normal View with Edit/Remove buttons */
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <DominoPiece sideA={piece.sideA} sideB={piece.sideB} size="sm" />
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-[11px] font-black text-zinc-400">#{index + 1}</span>
                              <p className="text-sm font-extrabold text-zinc-900 dark:text-zinc-100">
                                {piece.label}
                              </p>
                            </div>
                            <p className="text-[10px] text-zinc-500 dark:text-zinc-400">
                              {piece.sideA === piece.sideB
                                ? `Duplo de ${piece.sideA}`
                                : `${piece.sideA} + ${piece.sideB} = ${piece.points} pts`}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-black px-2 py-0.5 rounded-md bg-zinc-200 dark:bg-zinc-700 text-zinc-800 dark:text-zinc-200">
                            {piece.points} pts
                          </span>
                          <button
                            type="button"
                            onClick={() => handleStartPieceEdit(piece)}
                            aria-label={`Editar peça ${piece.label}`}
                            className="p-1.5 text-zinc-400 hover:text-amber-500 rounded-lg hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
                            title="Editar valores desta peça"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRemovePiece(piece.id)}
                            aria-label={`Excluir peça ${piece.label}`}
                            className="p-1.5 text-zinc-400 hover:text-red-500 rounded-lg hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
                            title="Remover peça da contagem"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Action Row: Assign to Player */}
          <div className="pt-3 border-t border-zinc-100 dark:border-zinc-800 space-y-3">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <div className="flex-1 flex items-center gap-2">
                <span className="text-xs font-semibold text-zinc-600 dark:text-zinc-300 whitespace-nowrap">
                  Atribuir a:
                </span>
                <select
                  aria-label="Selecionar jogador para atribuir pontuação"
                  value={selectedPlayerId}
                  onChange={(e) => setSelectedPlayerId(e.target.value)}
                  className="flex-1 bg-zinc-100 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-xl px-3 py-2 text-xs font-bold text-zinc-900 dark:text-zinc-100"
                >
                  {players.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.avatar} {p.name}
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="button"
                onClick={handleConfirmAssign}
                disabled={visionResult.pieces.length === 0}
                className="flex items-center justify-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-xs rounded-xl shadow-xs transition-all"
              >
                {assignSuccess ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-200" />
                    <span>Pontos e {visionResult.pieces.length} Peças Salvas!</span>
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Gravar {visionResult.totalPoints} pts na Rodada {currentRound}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
