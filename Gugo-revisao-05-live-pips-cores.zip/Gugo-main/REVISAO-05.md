# Revisão 05 — leitura por contraste e contagem em direto

## Alterações
- A deteção de pips combina agora o limiar de luminosidade com contraste local por janela integral. Isto reduz a dependência de uma única escala de cinzentos e ajuda a identificar pips cinzentos e amarelos em superfícies claras e sob iluminação quente.
- Ao abrir a câmara, a aplicação analisa frames reduzidos até 640 px a cada 450 ms, sem enviar imagens para serviços externos.
- A pré-visualização apresenta a quantidade de pips, o número de peças, os pontos provisórios e os valores por peça.
- Os centros dos pips e as caixas são desenhados por cima da imagem em direto.
- A análise final após a fotografia mantém-se e continua a permitir correção manual.

## Testes
- `node --test tests/camera-tab-regression.test.mjs`: 6/6 passaram.
- `python scripts/verify-reference-image.py`: passou para a fotografia de referência, 40 pips e 40 pontos.

## Limitações
- A pré-visualização depende da resolução, foco, iluminação e distância da câmara. Os números em direto são provisórios e devem ser confirmados antes de atribuir a pontuação.
- Não foi possível executar o build Vite nem validar num dispositivo Android nesta sessão, porque o pacote não inclui `node_modules` e não foi instalada a dependência.
- A validação de 40 pontos continua a ser um teste de referência específico, não uma garantia universal do detector.
